# SimpliLang Sözdizimi

## Değişken Tanımlama
```
degisken x = 5
```

## Yazdırma
```
yaz "Merhaba"
```

## Fonksiyon Çağırma
```
yaz topla(5, 3)
```
