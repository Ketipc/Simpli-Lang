def sayi_kontrol(s):
    try:
        float(s)
        return True
    except:
        return False
