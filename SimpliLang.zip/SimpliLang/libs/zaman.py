from datetime import datetime

def suan(args):
    return datetime.now().isoformat()
