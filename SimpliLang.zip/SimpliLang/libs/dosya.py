def oku(args):
    with open(args[0], 'r', encoding='utf-8') as f:
        return f.read()
